<?php 

defined('BASEPATH') OR exit('No direct script acces asllowed');

require APPPATH.'/libraries/REST_Controller.php';

class Layanan extends REST_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->model('Layanan_model', 'lLayanan');
    }
    public function index_post(){
        $request = json_decode(file_get_contents('php://input'),true);
        $query = $this->lLayanan->addLayanan($request);
        $this->response($query);
    }
    public function edit_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->lLayanan->editLayanan($request);
        $this->response($query);
    }
    public function delete_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->lLayanan->deleteLayanan($request);
        $this->response($query);
    }

    // get all data

    public function index_get(){
        $result["status"]           =200;
        $result["kode_response"]    ="00";
        $result["message"]          ="Request berhasil";
        $result['data']             =$this->db->get('layanan')->result();

        $this->response($result);
    }

    public function id_get($id){
        $result['data'] = $this->db->get_where('layanan', array('id' => $id)) -> row();
        $result['detail'] = $this->db->get_where("layanan", array("id"=>$id))->result();
        if(empty($result['data'])){
            $result["status"] = 404;
            $result["kode_response"] = "01";
            $result["message"] = "Data tidak di temukan";
            $result["data"] = "l";
        }else{
        $result["status"] = 200;
        $result["kode_response"] = "00";
        $result["message"] = "Request Berhasil";
    }
        $this->response($result);
    }
}

?>