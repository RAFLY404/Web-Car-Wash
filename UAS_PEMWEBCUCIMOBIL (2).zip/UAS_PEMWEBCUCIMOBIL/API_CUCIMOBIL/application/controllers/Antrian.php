<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH. '/libraries/REST_Controller.php';

class Antrian extends REST_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->model('Antrian_model', 'aAntrian');
    }

    // public function index_get(){
    //     $result["status"]           =200;
    //     $result["kode_response"]    ="00";
    //     $result["message"]          ="Request berhasil";
    //     $result['data']             =$this->db->get('antrian')->result();

    //     $this->response($result);
    // }

    public function index_get(){
        $result["status"] = 200;
        $result["kode_response"] = "00";
        $result["message"] = "Request Berhasil";
        $result['data'] = $this->db->query("SELECT * FROM antrian WHERE hari='".date('Y-m-d')."' ORDER BY nomor ASC") -> result();
        $this->response($result);
    }


    // public function date_get($date){
    //     $result["status"] = 200;
    //     $result["kode_response"] = "00";
    //     $result["message"] = "Request Berhasil";
    //     $result['data'] = $this->db->get_where('antrian', array('hari' => $date)) -> result();
    //     $this->response($result);
    // }

    public function index_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->aAntrian->addAntrian($request);
        $this->response($query);
    }

    public function edit_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->aAntrian->editAntrian($request);
        $this->response($query);
    }

}

?>