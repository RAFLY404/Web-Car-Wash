<?php 

defined('BASEPATH') OR exit('No direct script acces asllowed');

require APPPATH.'/libraries/REST_Controller.php';
class Users extends REST_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('Users_model', 'uUser');
    }
    public function data_get(){
        $result["Status"] = 200;
        $result["Kode_response"] = "00";
        $result["Message"] = "Request Berhasil";
        $result["Token"] = "token";
        $result["Nama"] = "Rafly Ramadhan";
        $this->response($result);
    }
    public function index_get(){
        $query = $this->uUser->getUser($this->get());
        $this->response($query);
    }
    public function index_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->uUser->addUser($request);
        $this->response($query);
    }

    public function edit_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->uUser->editUser($request);
        $this->response($query);
    }
    public function delete_post(){
        $request = json_decode(file_get_contents('php://input'), true);
        $query = $this->uUser->deleteUser($request);
        $this->response($query);
    }
    public function id_get($id){
        $result["status"]           =200;
        $result["kode_response"]    ="00";
        $result["message"]          ="Request berhasil";
        $result['data']             =$this->db->get_where('users', array('id'=>$id))->result();

        $this->response($result);
    }
    // public function index_get(){
    //     $result["status"]           =200;
    //     $result["kode_response"]    ="00";
    //     $result["message"]          ="Request berhasil";
    //     $result['data']             =$this->db->get('Users')->result();

    //     $this->response($result);
    // }
}

?>