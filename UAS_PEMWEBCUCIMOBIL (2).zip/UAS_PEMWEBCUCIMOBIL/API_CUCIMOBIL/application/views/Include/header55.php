<?php echo '
</head>
<body>
    <div id="box" style="width: 55pc;">
        <div id="banner">
                    
        </div>
        <div id="nav">
            <ul>
                <li><a href="index.php">Halaman Utama</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="kelola.php">Kelola Data</a></li>
            </ul>
        </div>
';
?>