<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
class Pemesanan_model extends CI_Model{
    
    private $response;

    public function addPemesanan($request){
        if (!empty($request)) {
            $cek = $this->db->get_where("pemesanan", array("user" => $request['user']));
            if($cek->num_rows() > 0){
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Gagal tambah data, Pesanan user belum selesai";
            } else {
                $insert = ['user'=>$request['user'],'totalharga'=>0];
                $result = $this->db->insert('pemesanan', $insert);
                $id = $this->db->insert_id();

                $data_detail = $request['detail'];
                $total = 0;
                foreach($data_detail as $row) {
                    $this->db->select('harga');
                    $this->db->from('layanan');
                    $this->db->where('id',$row['layanan']);

                    $subtotal = $this->db->get()->row()->harga;
                    $total+=$subtotal;
                    $insert2=['pemesanan'=>$id,'layanan'=>$row['layanan'],'harga'=>$subtotal];
                    $result2=$this->db->insert('pemesanandetail',$insert2);
                }
            

                
                $update=['totalharga'=>$total];
                $where= ['id'=>$id];

                $this->db->set($update);
                $this->db->where($where);
                $result = $this->db->update('pemesanan');
                $get_data = $this->db->get_where("pemesananview", array("id" => $id)) -> row();
                $get_detail = $this->db->get_where("pemesanandetailview", array("pemesanan"=>$id))->result();

                // $antri=0;
                // $antrian = $this->db->query("SELECT max(nomor) as n FROM antrian WHERE hari='".date('Y-m-d')."'") -> row()->n;
                // if ($antrian!=null) {
                //     // echo 'antrian berhasil ditemukan';
                //     $antri = $antrian;
                // } 
                // // else {
                // //     echo 'antrian gagal ditemukan';
                // // }
                // $antri+=1;

                // $inserta = ['pemesanan'=>$id,'nomor'=>$antri];
                // $resulta = $this->db->insert('antrian', $inserta);
                // $ida = $this->db->insert_id();
                $this->response['status'] = 200;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Berhasil tambah data";
                $this->response['data'] = $get_data;
                $this->response['detail']= $get_detail;
                // $this->response['antrian']= $antri;
            }

                
            // }
        } else {
            $this->response['status'] = 500;
            $this->response['message'] = "Data request is empty";
        }
        return $this->response;
    }

    public function editPemesanan($request){
        if (!empty($request)) {
            if (!empty($request['id'])) {
            $this->db->where("id", $request['id']);
            $cek = $this->db->get("pemesanan");

            if ($cek->num_rows() > 0) {
                $update = $request;
                unset($update['id']);
                $where['id'] = $request['id'];

                $this->db->set($update);
                $this->db->where($where);
                $result = $this->db->update('pemesanan');
                if ($result) {
                    $get_data = $this->db->get_where('pemesanan', array('id' => $request['id'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success update data Pemesanan";
                    $this->response['data'] = $get_data;
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed update data Pemesanan (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data id Pemesanan doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data id Pemesanan is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    } 
    public function deletePemesanan($request){
        if (!empty($request)) {
            if (!empty($request['id'])) {
            $this->db->where("id", $request['id']);
            $cek = $this->db->get("pemesanan");

            if ($cek->num_rows() > 0) {
                $delete = $request;
                unset($delete['id']);
                $where['id'] = $request['id'];

                $this->db->set($delete);
                $this->db->where($where);
                $result = $this->db->delete('pemesanan');
                if ($result) {
                    $get_data = $this->db->get_where('pemesanan', array('id' => $request['id'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success delete data Pemesanan";
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed delete data Pemesanan (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data id Pemesanan doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data id Pemesanan is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    } 
}




?>