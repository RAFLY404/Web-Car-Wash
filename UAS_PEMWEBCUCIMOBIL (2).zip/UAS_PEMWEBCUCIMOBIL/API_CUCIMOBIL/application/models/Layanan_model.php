<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
class Layanan_model extends CI_Model{

    private $response;

    public function addLayanan($request){
        if(!empty($request)){
            $cek = $this->db->get_where("layanan", array("nama" => $request['nama']));
            if($cek->num_rows() > 0){
                $this->response['status']           =201;
                $this->response['kode_response']    ="00";
                $this->response['message']          ="Gagal tambah data, nama layanan sudah ada";
            }else{
                $result = $this->db->insert('layanan', $request);
                $id = $this->db->insert_id();

                $get_data = $this->db->get_where("layanan", array("id" => $id))->row();
                
                $this->response['status']           =200;
                $this->response['kode_response']    ="00";
                $this->response['message']          ="Berhasil Tambah Data";
                $this->response['status']           =$get_data;
            }
        }else{
            $this->response['status']   = 500;
            $this->response['message']  ="Data request is empty";
        }
        return $this->response;
    }

    public function editLayanan($request){
        if (!empty($request)) {
            if (!empty($request['id'])) {
            $this->db->where("id", $request['id']);
            $cek = $this->db->get("layanan");

            if ($cek->num_rows() > 0) {
                $update = $request;
                unset($update['id']);
                $where['id'] = $request['id'];

                $this->db->set($update);
                $this->db->where($where);
                $result = $this->db->update('layanan');
                if ($result) {
                    $get_data = $this->db->get_where('layanan', array('id' => $request['id'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success update data layanan";
                    $this->response['data'] =$get_data;
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed update data layanan (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data id layanan doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data id layanan is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    } 
    public function deleteLayanan($request){
        if (!empty($request)) {
            if (!empty($request['id'])) {
            $this->db->where("id", $request['id']);
            $cek = $this->db->get("layanan");

            if ($cek->num_rows() > 0) {
                $delete = $request;
                unset($delete['id']);
                $where['id'] = $request['id'];

                $this->db->set($delete);
                $this->db->where($where);
                $result = $this->db->delete('layanan');
                if ($result) {
                    // $get_data = $this->db->get_where('layanan', array('id' => $request['id'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success delete data layanan";
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed delete data layanan (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data id layanan doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data id layanan is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    } 
}
?>