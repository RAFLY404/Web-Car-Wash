<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
class Antrian_model extends CI_Model{
    
    private $response;

    public function addAntrian($request){
        if (!empty($request)) {
            // $cek = $this->db->get_where("antrian", array("nama" => $request['nama']));
            // if($cek->num_rows() > 0){
            //     $this->response['status'] = 201;
            //     $this->response['kode_response'] = "00";
            //     $this->response['message'] = "Gagal tambah data, nama antrian sudah ada";
            // } else {
                // $result = $this->db->insert('antrian', $request);
                // $nomor = $this->db->insert_nomor();

                // $get_data = $this->db->get_where("antrian", array("nomor" => $nomor)) -> row();
                $antri=0;
                $antrian = $this->db->query("SELECT max(nomor) as n FROM antrian WHERE hari='".date('Y-m-d')."'") -> row()->n;
                if ($antrian!=null) {
                    // echo 'antrian berhasil ditemukan';
                    $antri = $antrian;
                } 
                // else {
                //     echo 'antrian gagal ditemukan';
                // }
                $antri+=1;

                $inserta = ['pemesanan'=>$request['pemesanan'],'nomor'=>$antri];
                $resulta = $this->db->insert('antrian', $inserta);
                $get_data = $this->db->query("SELECT * FROM antrian WHERE hari='".date('Y-m-d')."' AND nomor=".$antri) -> row();
                $this->response['status'] = 200;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Berhasil tambah antrian";
                $this->response['data'] = $get_data;
            // }
        } else {
            $this->response['status'] = 500;
            $this->response['message'] = "Data request is empty";
        }
        return $this->response;
    }

    public function editAntrian($request){
        if (!empty($request)) {
            if (!empty($request['nomor'])) {
            $this->db->where("nomor", $request['nomor']);
            $cek = $this->db->get("antrian");

            if ($cek->num_rows() > 0) {
                $update = $request;
                unset($update['nomor']);
                $where['nomor'] = $request['nomor'];

                $this->db->set($update);
                $this->db->where($where);
                $result = $this->db->update('antrian');
                if ($result) {
                    $get_data = $this->db->get_where('antrian', array('nomor' => $request['nomor'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success update data antrian";
                    $this->response['data'] = $get_data;
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed update data antrian (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data nomor antrian doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data nomor antrian is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    } 
}



?>