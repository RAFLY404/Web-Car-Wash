<?php 

defined('BASEPATH') OR exit('No direct script acces allowed');
class Users_model extends CI_Model{
    private $response;

    function get_token(){
        $char = "abcdefghijklmnopqrstuABCDEFGHIJKLMNOPQRSTU1234567890._";
        $token = '';
        for ($i = 0; $i < 166; $i++) $token .= $char[(rand() % strlen($char))];
        return $token;
    }
    public function getUser($request){
        if(!empty($request)){
            $update = 0;
            $_where = array("username" => $request["username"],
                            "password" => md5($request["password"]) );

            $query = $this->db->get_where("users", $_where);
            if($query->num_rows() > 0){
                $row = $query->row();

                if(date('Y-m-d H:i:s') > $row->session_time){
                    $token = $this->get_token();
                    $update = 1;
                }else{
                    $token = $row->token;
                }
            }else{
                $this->response['status'] = 401;
                $this->response['message'] = "Bad request [invalid credential]";
                
                $result['Result'] = $this->response;
                return $result;
            }

            if($update){
                $this->db->where("username", $request['username']);
                $this->db->where("password", md5($request['password']));
                $this->db->update(
                    "users", array(
                        "session_time" => date('Y-m-d H:i:s', strtotime(date('Y-m-dH:i:s').' +1 day')),
                        "token" => $token
                ));
            }

            $this->response['status'] = 200;
            $this->response['kode_response'] = "00";
            $this->response['message'] = "Request Berhasil";;
            $this->response['token'] = $token;
        }else {
            $this->response['status'] = 500;
            $this->response['message'] = "Data get is empty";
        }
        return $this->response;
    }

    public function addUser($request){
        if (!empty($request)) {
            $cek = $this->db->get_where("users", array("username" => $request['username']));
            if($cek->num_rows() > 0){
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Gagal tambah data, username sudah ada";
            } else {
                $request["password1"]=$request["password"];
                $request["password"]=md5($request["password"]);
                $request = $this->db->insert('users', $request);
                $id = $this->db->insert_id();

                $get_data = $this->db->get_where("users", array("id" => $id)) -> row();

                $this->response['status'] = 200;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Berhasil tambah data";
                $this->response['data'] = $get_data;
            }
        } else {
            $this->response['status'] = 500;
            $this->response['message'] = "Data request is empty";
        }
        return $this->response;
    }

    
    public function editUser($request){
        if (!empty($request)) {
            if (!empty($request['id'])) {
            $this->db->where("id", $request['id']);
            $cek = $this->db->get("users");

            if ($cek->num_rows() > 0) {
                if(!empty($request['password'])) {
                    $request['password1'] = $request['password'];
                    $request['password'] = md5($request['password']);
                }
                $update = $request;
                unset($update['id']);
                $where['id'] = $request['id'];

                $this->db->set($update);
                $this->db->where($where);
                $result = $this->db->update('users');
                if ($result) {
                    $get_data = $this->db->get_where('users', array('id' => $request['id'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success update data users";
                    $this->response['data'] = $get_data;
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed update data users (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data id users doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data id users is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    }

    public function deleteUser($request){
        if (!empty($request)) {
            if (!empty($request['id'])) {
            $this->db->where("id", $request['id']);
            $cek = $this->db->get("users");

            if ($cek->num_rows() > 0) {
                $delete = $request;
                unset($delete['id']);
                $where['id'] = $request['id'];

                $this->db->set($delete);
                $this->db->where($where);
                $result = $this->db->delete('users');
                if ($result) {
                    $get_data = $this->db->get_where('users', array('id' => $request['id'])) -> row();

                    $this->response['status'] = 200;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Success delete data Users";
                } else {
                    $this->response['status'] = 201;
                    $this->response['kode_response'] = "00";
                    $this->response['message'] = "Failed delete data Users (Error: ".$this->db->error().")";
                }
            } else {
                $this->response['status'] = 201;
                $this->response['kode_response'] = "00";
                $this->response['message'] = "Data id Users doesn't exists";
            }
        } else {
            $this->response['status'] = 201;
            $this->response['message'] = "Data id Users is empty";
        }
    } else {
        $this->response['status'] = 500;
        $this->response['message'] = "Data request is empty";
    }
    return $this->response;
    } 

    // public function editUserbyUser($request){
    //     if (!empty($request)) {
    //         if (!empty($request['id'])) {
    //         $this->db->where("id", $request['id']);
    //         $cek = $this->db->get("users");

    //         if ($cek->num_rows() > 0) {
    //             if (!empty($request['oldpassword']) || )
    //                 if(!empty($request['password'])) {
    //                     $request['password1'] = $request['password'];
    //                     $request['password'] = md5($request['password']);
    //                 }
    //                 $update = $request;
    //                 unset($update['id']);
    //                 $where['id'] = $request['id'];

    //                 $this->db->set($update);
    //                 $this->db->where($where);
    //                 $result = $this->db->update('users');
    //                 if ($result) {
    //                     $get_data = $this->db->get_where('users', array('id' => $request['id'])) -> row();

    //                     $this->response['status'] = 200;
    //                     $this->response['kode_response'] = "00";
    //                     $this->response['message'] = "Success update data users";
    //                     $this->response['data'] = $get_data;
    //                 } else {
    //                     $this->response['status'] = 201;
    //                     $this->response['kode_response'] = "00";
    //                     $this->response['message'] = "Failed update data users (Error: ".$this->db->error().")";
    //                 }
    //         } else {
    //             $this->response['status'] = 201;
    //             $this->response['kode_response'] = "00";
    //             $this->response['message'] = "Data id users doesn't exists";
    //         }
    //     } else {
    //         $this->response['status'] = 201;
    //         $this->response['message'] = "Data id users is empty";
    //     }
    // } else {
    //     $this->response['status'] = 500;
    //     $this->response['message'] = "Data request is empty";
    // }
    // return $this->response;
    // }

}



?>