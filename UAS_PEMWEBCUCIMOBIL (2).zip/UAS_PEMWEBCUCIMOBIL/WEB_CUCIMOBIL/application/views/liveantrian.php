<?php
include "Include/Header.php";
?>

<!-- Internal CSS -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<style>
  * {
    padding:0;
    margin:0;
    box-sizing: border-box;
    font-family: poppins;
}
body {
    background-color: lightgray;
}
#nav {
    background-color: #A7727D;
    width: 100%;
}
#nav ul {
    text-align: center;
}
#nav ul li {
    display: inline;
}
#nav ul li a {
    text-decoration: none;
    color: white;
    display: inline-block;
    padding: 8px 16px;
    margin: 0px -2px;
}

#banner {
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    margin-top: 100px;
    height: 10pc;
}
#footer {
    background-color: #F9F5E7; 
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    margin-top: 1pc;
}
#footer p {
    color:black; 
    font-size: 13px;
    text-align: center; 
    padding: 0.5pc;
}
#box {
    margin-left: auto;
    margin-right: auto;
    
}

.regist {
    width: 100%;
    background-color: #F8EAD8;
}
.regist form {
    size: fit-content;
}
.regist table {
    margin: 0 auto;
    padding: 10px 0;
    width: 90%; 
    border-collapse: collapse;
}
.regist th,
.regist td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}
.regist th {
    background-color: #EDDBC7;
    color: #000;
}
.inp {
    width: 100%;
}
.tdsubmit {
    text-align: center;
}
.tombolsubmit {
    width: 50%;
}
</style>

<?php include "Include/Header50.php"; ?>

<!-- Content -->
<div class="regist">
  <table>
    <tr>
      <th>No.</th>
      <th>ID Pesanan</th>
      <th>Status</th>
    </tr>
    <?php foreach ($data as $a): ?>
      <tr>
        <td><?php echo $a['nomor']; ?></td>
        <td><?php echo $a['pemesanan']; ?></td>
        <td>
          <?php
          if ($a['status'] == 0) {
            echo "Pending";
          } else if ($a['status'] == 1) {
            echo "Proses";
          } else if ($a['status'] >= 1) {
            echo "Selesai";
          }
          ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include "Include/Footer.php"; ?>