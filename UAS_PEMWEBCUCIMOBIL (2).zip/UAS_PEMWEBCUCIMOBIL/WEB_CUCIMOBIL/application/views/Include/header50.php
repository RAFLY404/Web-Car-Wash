<?php echo '
</head>
<body>
    <div id="box" style="width: 50pc;">
        <div id="banner">
                    
        </div>
        <div id="nav">
            <ul>
                <li><a>Antrian Cuci Mobil</a></li>
            </ul>
        </div>
';
?>