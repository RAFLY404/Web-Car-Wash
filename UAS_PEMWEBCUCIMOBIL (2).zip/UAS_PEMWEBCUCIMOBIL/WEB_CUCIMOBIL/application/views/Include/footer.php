<style>
    .p {
        text-align: left;
    }
    .date-time {
        text-align: right;
    }
</style>

<div id="footer">
    <p class="p">Rafly Ramadhan XI - RPL</p>
    <p class="date-time" id="datetime"></p>
</div>
</div>
</body>
</html>

<script>
    function updateTime() {
        var datetimeElement = document.getElementById("datetime");
        var now = new Date();
        var options = { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
        var datetimeString = now.toLocaleDateString('en-US', options);
        datetimeElement.innerHTML = datetimeString;
    }

    // Update time every second
    setInterval(updateTime, 1000);
</script>