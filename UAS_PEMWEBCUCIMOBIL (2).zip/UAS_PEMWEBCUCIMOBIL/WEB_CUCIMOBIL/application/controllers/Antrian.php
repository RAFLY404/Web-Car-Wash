<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH. '/libraries/REST_Controller.php';

class Antrian extends REST_Controller{
    public function __construct(){
        parent::__construct();
        // $this->load->model('Antrian_model', 'aAntrian');
        $this->load->model('Curl');
    }

    


    public function index_get(){
        $body['url']=$this->Curl->get_url().'/index.php/antrian';
        $get = json_decode($this->Curl->http_request($body,'','GET'), TRUE);
        $data['data']           = $get['data'];

        $this->load->view('liveantrian',$data);
    }


}

?>